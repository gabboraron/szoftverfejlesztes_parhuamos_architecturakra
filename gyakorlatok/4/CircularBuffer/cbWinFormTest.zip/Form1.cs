//
// Copyright (C) 2002 Robert Hinrichs. All rights reserved.
// bobh@inav.net
// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
// WARRANTIES OF MERCHANTIBILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
//
// Disclaimer:
// Don't study this file if you are learning C#--it's pretty much of a 
// quick hack to demonstrate the Circular Buffer.
// I did a much better job with class QueueCB and ran it through Microsoft's
// FxCop to check for style.
// This app just sort of happened as a test harness for the cb class
// 
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Threading;

using CircularBuffer;

namespace CircularBufferTestWinForm
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	/// 
		public enum CBPriority 
		{
		Low, High
		}

	public class Form1 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		/// 
		
		// global statics used by namespace
		static public QueueCB theCB;
		static public System.Windows.Forms.Timer timer;
		static bool Running = false;

        bool CircularBufferSyncMode;
		
        // Producer Configuration
        static public System.Double PWriteInterval;
		static public System.Int32 PWriteNumber;
		static public bool  PBlockingWrite;
		static public CBPriority PPriority;
		
        // Consumer Configuration
        static public System.Double CReadInterval;
		static public System.Int32 CReadNumber, CReadWaterMark;
		static public bool  CBlockingRead, CBUseWaterMark;
		static public CBPriority CPriority;

		// Circular Buffer State
		System.Int32 CBcount = 0; 
		System.Int32 CBreadindex = 0;
		System.Int32 CBwriteindex = 0;
		

		Rectangle rectouter, rectinner;
		bool UpdateDisplay = false;
		Point[] apt = new Point[4];
		
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button StartButton;

		const System.Int32 TimerInterval = 250;// msec. 1/2 of display interval

		Thread consumerThread, producerThread;

		const System.Int32 CircleX = 500;
		const System.Int32 CircleY = 500;
		Pen pen;
		Brush brush;
		Brush brush2;
		Brush Obrush;
		Brush LObrush;
		Color thinnerOrange;

		private System.Windows.Forms.Button StopButton;

		Font textFont = new Font("Times New Roman", 18);
		private System.Windows.Forms.RadioButton SyncModeRadioButton;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox CountTextBox;
		private System.Windows.Forms.Label CountLabel;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.TextBox PIntervalTextBox;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox PNumberTextBox;
		private System.Windows.Forms.Button ExitButton;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox CNumberTextBox;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox CIntervalTextBox;
		private System.Windows.Forms.RadioButton BWriteRadioButton;
		private System.Windows.Forms.RadioButton BReadRadioButton;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.RadioButton TimedRadioButton;
		private System.Windows.Forms.RadioButton WaterMarkRadioButton;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox WMNumberTextBox;
		private System.Windows.Forms.RadioButton AsyncModeRadioButton;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
			
			BackColor = SystemColors.Window;
			ForeColor = SystemColors.WindowText;
			Text = "Circular Buffer Test";

			rectouter = new Rectangle(-500, -500, 1000-2, 1000-2);
			rectinner = new Rectangle(-450, -450, 900, 900);

			pen = new Pen(ForeColor);
			brush = new SolidBrush(Color.AliceBlue);
			brush2 = new SolidBrush(Color.LightCoral);

			Color thinOrange = Color.FromArgb(230,Color.DarkOrange);
			Obrush = new SolidBrush(thinOrange);

			Color thinerOrange = Color.FromArgb(150,Color.DarkOrange);
			thinnerOrange = thinerOrange;
			LObrush = new SolidBrush(thinerOrange);


			/* an approximation to the area between the two circles */
			/* and the DrawPie() radii for fillpolygon() */
			/* Could spend more time here */
			apt[0] = new Point(455,4);
			apt[1] = new Point(497,4);
			apt[2] = new Point(486,84);
			apt[3] = new Point(446,77);

			// Default Circular Buffer Mode
            CircularBufferSyncMode =  true;
//			CircularBufferSyncMode =  false;
		
			//***************************************************************
			// Default Producer Configuration
            PWriteInterval = 1000; 
            PWriteNumber = 10;
	    	PBlockingWrite = false;
	     	PPriority = CBPriority.High;
		
			//***************************************************************
			// Default Consumer Configuration
			//*** test
			// simulate a little timing error
			// also eliminates possible timing hazard on start-up
			// Well it did on a two processor system but not a single
			// CPU.
            CReadInterval = 1100; // s/b 1000
	        CReadNumber = 10;
		    CBlockingRead = false;
			CBUseWaterMark = false;
			CReadWaterMark = 13*10; // ten items per entry for display
	   	    CPriority = CBPriority.Low;

			// create Circular Buffer of size 360
			// The user sees a 36 item cb with N-1 or 35
			// useable locations.
			// To get the display (which shows 10 degrees per item)
			// and the Circ. Buffer count to be in sync, we will 
			// write 10 items at a time. The viewer will be tricked
			// into thinking the Circular Buffer size is 36. We
			// will multiply all user inputs by 10 and divide
			// all circ. buffer internal values by 10.
			theCB = new QueueCB(360);
			theCB.Synchronousmode = CircularBufferSyncMode;
			if(CBUseWaterMark==true)
			{
				theCB.Watermarkflag = true; // use the watermark
				theCB.Watermark = CReadWaterMark;
			}
			else
			{
				theCB.Watermarkflag = false; // don't use the watermark
				theCB.Watermark = CReadWaterMark;										
			}

			WMNumberTextBox.Enabled = false;
			WMNumberTextBox.BackColor = Color.LightGray;



			//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//
			theCB.WaterMarkNotify += new QueueCB.CBEventHandler(WaterMarkEvent);
			//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

			timer = new System.Windows.Forms.Timer();
			timer.Tick += new EventHandler(TimerOnTick);
			timer.Interval = TimerInterval;	
		
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(producerThread != null)
					if(producerThread.IsAlive)
						producerThread.Abort();
				if(consumerThread != null)
					if(consumerThread.IsAlive)
						consumerThread.Abort();
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.BWriteRadioButton = new System.Windows.Forms.RadioButton();
			this.BReadRadioButton = new System.Windows.Forms.RadioButton();
			this.ExitButton = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label2 = new System.Windows.Forms.Label();
			this.PNumberTextBox = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.PIntervalTextBox = new System.Windows.Forms.TextBox();
			this.CountLabel = new System.Windows.Forms.Label();
			this.CountTextBox = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.SyncModeRadioButton = new System.Windows.Forms.RadioButton();
			this.AsyncModeRadioButton = new System.Windows.Forms.RadioButton();
			this.StopButton = new System.Windows.Forms.Button();
			this.StartButton = new System.Windows.Forms.Button();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.label6 = new System.Windows.Forms.Label();
			this.TimedRadioButton = new System.Windows.Forms.RadioButton();
			this.label3 = new System.Windows.Forms.Label();
			this.CNumberTextBox = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.CIntervalTextBox = new System.Windows.Forms.TextBox();
			this.WaterMarkRadioButton = new System.Windows.Forms.RadioButton();
			this.WMNumberTextBox = new System.Windows.Forms.TextBox();
			this.panel2.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.White;
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(504, 512);
			this.panel1.TabIndex = 0;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.SystemColors.ControlLight;
			this.panel2.Controls.AddRange(new System.Windows.Forms.Control[] {
																				 this.groupBox4,
																				 this.ExitButton,
																				 this.groupBox2,
																				 this.CountLabel,
																				 this.CountTextBox,
																				 this.groupBox1,
																				 this.StopButton,
																				 this.StartButton,
																				 this.groupBox3});
			this.panel2.Location = new System.Drawing.Point(512, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(192, 520);
			this.panel2.TabIndex = 1;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.BWriteRadioButton,
																					this.BReadRadioButton});
			this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox4.Location = new System.Drawing.Point(24, 72);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(152, 56);
			this.groupBox4.TabIndex = 12;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Write/Read Operations";
			// 
			// BWriteRadioButton
			// 
			this.BWriteRadioButton.Checked = true;
			this.BWriteRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.BWriteRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.BWriteRadioButton.Location = new System.Drawing.Point(8, 16);
			this.BWriteRadioButton.Name = "BWriteRadioButton";
			this.BWriteRadioButton.Size = new System.Drawing.Size(136, 16);
			this.BWriteRadioButton.TabIndex = 11;
			this.BWriteRadioButton.TabStop = true;
			this.BWriteRadioButton.Text = "Non-Blocking ";
			this.BWriteRadioButton.CheckedChanged += new System.EventHandler(this.BWriteRadioButton_CheckedChanged);
			// 
			// BReadRadioButton
			// 
			this.BReadRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.BReadRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.BReadRadioButton.Location = new System.Drawing.Point(8, 32);
			this.BReadRadioButton.Name = "BReadRadioButton";
			this.BReadRadioButton.Size = new System.Drawing.Size(120, 16);
			this.BReadRadioButton.TabIndex = 11;
			this.BReadRadioButton.Text = "Blocking";
			// 
			// ExitButton
			// 
			this.ExitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.ExitButton.Location = new System.Drawing.Point(56, 480);
			this.ExitButton.Name = "ExitButton";
			this.ExitButton.TabIndex = 9;
			this.ExitButton.Text = "Exit";
			this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.label2,
																					this.PNumberTextBox,
																					this.label1,
																					this.PIntervalTextBox});
			this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox2.Location = new System.Drawing.Point(8, 152);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(176, 88);
			this.groupBox2.TabIndex = 8;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Producer";
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label2.Location = new System.Drawing.Point(8, 48);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(120, 23);
			this.label2.TabIndex = 10;
			this.label2.Text = "Write Num.  (Items)";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// PNumberTextBox
			// 
			this.PNumberTextBox.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.PNumberTextBox.Location = new System.Drawing.Point(136, 48);
			this.PNumberTextBox.Name = "PNumberTextBox";
			this.PNumberTextBox.Size = new System.Drawing.Size(32, 21);
			this.PNumberTextBox.TabIndex = 9;
			this.PNumberTextBox.Text = "1";
			this.PNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.PNumberTextBox.TextChanged += new System.EventHandler(this.PNumber_TextChanged);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label1.Location = new System.Drawing.Point(8, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(120, 23);
			this.label1.TabIndex = 8;
			this.label1.Text = "Write Interval (Sec.)";
			// 
			// PIntervalTextBox
			// 
			this.PIntervalTextBox.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.PIntervalTextBox.Location = new System.Drawing.Point(136, 24);
			this.PIntervalTextBox.Name = "PIntervalTextBox";
			this.PIntervalTextBox.Size = new System.Drawing.Size(32, 21);
			this.PIntervalTextBox.TabIndex = 7;
			this.PIntervalTextBox.Text = "1";
			this.PIntervalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.PIntervalTextBox.TextChanged += new System.EventHandler(this.PIntervalTextBox_TextChanged);
			// 
			// CountLabel
			// 
			this.CountLabel.Location = new System.Drawing.Point(16, 416);
			this.CountLabel.Name = "CountLabel";
			this.CountLabel.Size = new System.Drawing.Size(72, 40);
			this.CountLabel.TabIndex = 6;
			this.CountLabel.Text = "Buffer Count (35 max)";
			// 
			// CountTextBox
			// 
			this.CountTextBox.Location = new System.Drawing.Point(88, 424);
			this.CountTextBox.Name = "CountTextBox";
			this.CountTextBox.ReadOnly = true;
			this.CountTextBox.Size = new System.Drawing.Size(32, 20);
			this.CountTextBox.TabIndex = 5;
			this.CountTextBox.Text = "";
			this.CountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.SyncModeRadioButton,
																					this.AsyncModeRadioButton});
			this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox1.Location = new System.Drawing.Point(24, 8);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(152, 56);
			this.groupBox1.TabIndex = 4;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Circular Buffer Mode";
			// 
			// SyncModeRadioButton
			// 
			this.SyncModeRadioButton.Checked = true;
			this.SyncModeRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.SyncModeRadioButton.Location = new System.Drawing.Point(8, 16);
			this.SyncModeRadioButton.Name = "SyncModeRadioButton";
			this.SyncModeRadioButton.Size = new System.Drawing.Size(112, 16);
			this.SyncModeRadioButton.TabIndex = 2;
			this.SyncModeRadioButton.TabStop = true;
			this.SyncModeRadioButton.Text = "Sync Mode";
			this.SyncModeRadioButton.CheckedChanged += new System.EventHandler(this.SyncModeRadioButton_CheckedChanged);
			// 
			// AsyncModeRadioButton
			// 
			this.AsyncModeRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.AsyncModeRadioButton.Location = new System.Drawing.Point(8, 32);
			this.AsyncModeRadioButton.Name = "AsyncModeRadioButton";
			this.AsyncModeRadioButton.Size = new System.Drawing.Size(120, 16);
			this.AsyncModeRadioButton.TabIndex = 3;
			this.AsyncModeRadioButton.Text = "Async Mode";
			this.AsyncModeRadioButton.CheckedChanged += new System.EventHandler(this.AsyncRadioButton_CheckedChanged);
			// 
			// StopButton
			// 
			this.StopButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.StopButton.Location = new System.Drawing.Point(96, 456);
			this.StopButton.Name = "StopButton";
			this.StopButton.TabIndex = 1;
			this.StopButton.Text = "Stop";
			this.StopButton.Click += new System.EventHandler(this.StopButton_Click);
			// 
			// StartButton
			// 
			this.StartButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.StartButton.Location = new System.Drawing.Point(16, 456);
			this.StartButton.Name = "StartButton";
			this.StartButton.TabIndex = 0;
			this.StartButton.Text = "Start";
			this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.AddRange(new System.Windows.Forms.Control[] {
																					this.WMNumberTextBox,
																					this.label6,
																					this.TimedRadioButton,
																					this.label3,
																					this.CNumberTextBox,
																					this.label4,
																					this.CIntervalTextBox,
																					this.WaterMarkRadioButton});
			this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.groupBox3.Location = new System.Drawing.Point(8, 240);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(176, 160);
			this.groupBox3.TabIndex = 11;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Consumer";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(8, 136);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(120, 16);
			this.label6.TabIndex = 14;
			this.label6.Text = "WaterMark Level";
			// 
			// TimedRadioButton
			// 
			this.TimedRadioButton.Checked = true;
			this.TimedRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.TimedRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.TimedRadioButton.Location = new System.Drawing.Point(8, 64);
			this.TimedRadioButton.Name = "TimedRadioButton";
			this.TimedRadioButton.Size = new System.Drawing.Size(104, 16);
			this.TimedRadioButton.TabIndex = 11;
			this.TimedRadioButton.TabStop = true;
			this.TimedRadioButton.Text = "Timed";
			this.TimedRadioButton.CheckedChanged += new System.EventHandler(this.TimedRadioButton_CheckedChanged);
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.label3.Location = new System.Drawing.Point(8, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(104, 23);
			this.label3.TabIndex = 10;
			this.label3.Text = "Read Num.  (Items)";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// CNumberTextBox
			// 
			this.CNumberTextBox.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.CNumberTextBox.Location = new System.Drawing.Point(136, 16);
			this.CNumberTextBox.Name = "CNumberTextBox";
			this.CNumberTextBox.Size = new System.Drawing.Size(32, 21);
			this.CNumberTextBox.TabIndex = 9;
			this.CNumberTextBox.Text = "1";
			this.CNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.CNumberTextBox.TextChanged += new System.EventHandler(this.CNumberTextBox_TextChanged);
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(8, 112);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(120, 23);
			this.label4.TabIndex = 8;
			this.label4.Text = "Read Interval (Sec.)";
			// 
			// CIntervalTextBox
			// 
			this.CIntervalTextBox.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.CIntervalTextBox.Location = new System.Drawing.Point(136, 112);
			this.CIntervalTextBox.Name = "CIntervalTextBox";
			this.CIntervalTextBox.Size = new System.Drawing.Size(32, 21);
			this.CIntervalTextBox.TabIndex = 7;
			this.CIntervalTextBox.Text = "1";
			this.CIntervalTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.CIntervalTextBox.TextChanged += new System.EventHandler(this.CIntervalTextBox_TextChanged);
			// 
			// WaterMarkRadioButton
			// 
			this.WaterMarkRadioButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.WaterMarkRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.WaterMarkRadioButton.Location = new System.Drawing.Point(8, 80);
			this.WaterMarkRadioButton.Name = "WaterMarkRadioButton";
			this.WaterMarkRadioButton.Size = new System.Drawing.Size(104, 16);
			this.WaterMarkRadioButton.TabIndex = 12;
			this.WaterMarkRadioButton.Text = "WaterMark";
			this.WaterMarkRadioButton.CheckedChanged += new System.EventHandler(this.WaterMarkRadioButton_CheckedChanged);
			// 
			// WMNumberTextBox
			// 
			this.WMNumberTextBox.BackColor = System.Drawing.Color.FromArgb(((System.Byte)(192)), ((System.Byte)(255)), ((System.Byte)(255)));
			this.WMNumberTextBox.Location = new System.Drawing.Point(136, 136);
			this.WMNumberTextBox.Name = "WMNumberTextBox";
			this.WMNumberTextBox.Size = new System.Drawing.Size(32, 21);
			this.WMNumberTextBox.TabIndex = 15;
			this.WMNumberTextBox.Text = "13";
			this.WMNumberTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			this.WMNumberTextBox.TextChanged += new System.EventHandler(this.WMNumberTextBox_TextChanged);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(704, 509);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.panel2,
																		  this.panel1});
			this.Name = "Form1";
			this.Text = "CircularBuffer Demo";
			this.panel2.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		protected override void OnPaint(PaintEventArgs ea)
		{
				PaintPage(ea.Graphics, ForeColor, 
					ClientSize.Width, ClientSize.Height);
		}
		protected override void OnResize(EventArgs ea)
		{
			Invalidate();
		}
		protected override void OnMove(EventArgs ea)
		{
			Invalidate();
		}

		private void TimerOnTick(object sender, EventArgs e)
		{
			System.Int32 tempi;

			CBcount = theCB.Count;
			CBreadindex = theCB.ReadIndex*10; // 10 degrees/display item
			CBwriteindex = theCB.WriteIndex*10; // 10 degrees/display item

			tempi = CBcount/10;
			CountTextBox.Text = tempi.ToString();

			if(UpdateDisplay == true)
			{
				UpdateDisplay = false;
				Invalidate();
			}
			else
				UpdateDisplay = true;
		}

		private void StartButton_Click(object sender, System.EventArgs e)
		{
			Running = true;
			DisableControls();

			Producer producer = new Producer();
			Consumer consumer = new Consumer();

			producer.Parent = this;
			consumer.Parent = this;

			producerThread = 
				new Thread(new ThreadStart(producer.Generate));
			producerThread.Name = "Producer";
//			producerThread.Priority = (System.Threading.ThreadPriority)PPriority;

			consumerThread = 
				new Thread(new ThreadStart(consumer.Consume));
			consumerThread.Name = "Consumer";
//			consumerThread.Priority = (System.Threading.ThreadPriority)CPriority;


			producerThread.Start();
			consumerThread.Start();
			timer.Start();		
		}

		private void StopButton_Click(object sender, System.EventArgs e)
		{
			ClearDisplay();
		}

		public void ClearDisplay()
		{
			Running = false;
			timer.Stop();
			try
			{
				if(producerThread.IsAlive)
					producerThread.Abort();
				if(consumerThread.IsAlive)
					consumerThread.Abort();
			}
			catch
			{

			}
			EnableControls();
			theCB.Clear();
			TimerOnTick(this, null);
			TimerOnTick(this, null);		

		}

		private void DisableControls()
		{
			SyncModeRadioButton.Enabled = false;
			AsyncModeRadioButton.Enabled = false;
			BWriteRadioButton.Enabled = false;
			BReadRadioButton.Enabled = false;
			TimedRadioButton.Enabled = false;
			WaterMarkRadioButton.Enabled = false;
			if(CBUseWaterMark==true)
			{
				WMNumberTextBox.Enabled = true;
				CIntervalTextBox.Enabled = false;
				CIntervalTextBox.BackColor = Color.LightGray;
			}
			else
			{
				WMNumberTextBox.Enabled = false;
				WMNumberTextBox.BackColor = Color.LightGray;
				CIntervalTextBox.Enabled = true;
			}

		}
		private void EnableControls()
		{
			SyncModeRadioButton.Enabled = true;
			AsyncModeRadioButton.Enabled = true;
			BWriteRadioButton.Enabled = true;
			BReadRadioButton.Enabled = true;
			TimedRadioButton.Enabled = true;
			WaterMarkRadioButton.Enabled = true;
			if(CBUseWaterMark==true)
			{
				WMNumberTextBox.Enabled = true;
				WMNumberTextBox.BackColor = Color.FromArgb(192,255,255);
				CIntervalTextBox.Enabled = false;
				CIntervalTextBox.BackColor = Color.LightGray;
			}
			else
			{
				WMNumberTextBox.Enabled = false;
				WMNumberTextBox.BackColor = Color.LightGray;
				CIntervalTextBox.Enabled = true;
				CIntervalTextBox.BackColor = Color.FromArgb(192,255,255);
			}
		}

		private void SyncModeRadioButton_CheckedChanged(object sender, System.EventArgs e)
		{
			if(Running == false)
			{
				CircularBufferSyncMode =  true;
				theCB.Synchronousmode = CircularBufferSyncMode;
			}
		
		}

		private void AsyncRadioButton_CheckedChanged(object sender, System.EventArgs e)
		{
			if(Running==false)
			{
				CircularBufferSyncMode =  false;
				theCB.Synchronousmode = CircularBufferSyncMode;
			}
		
		}

		private void TimedRadioButton_CheckedChanged(object sender, System.EventArgs e)
		{
			if(Running==false)
			{
				CBUseWaterMark = false;
				theCB.Watermarkflag = false; // don't use the watermark

				WMNumberTextBox.Enabled = false;
				WMNumberTextBox.BackColor = Color.LightGray;
				CIntervalTextBox.Enabled = true;
				CIntervalTextBox.BackColor = Color.FromArgb(192,255,255);

			}
		
		}

		private void WaterMarkRadioButton_CheckedChanged(object sender, 
			System.EventArgs e)
		{
			if(Running==false)
			{
				CBUseWaterMark = true;
				theCB.Watermarkflag = true; // don't use the watermark
				theCB.Watermark = CReadWaterMark;	
				
				WMNumberTextBox.Enabled = true;
				WMNumberTextBox.BackColor = Color.FromArgb(192,255,255);
				CIntervalTextBox.Enabled = false;
				CIntervalTextBox.BackColor = Color.LightGray;					

			}
		
		}

		private void PIntervalTextBox_TextChanged(object sender, System.EventArgs e)
		{
			System.Double tempf;
			try
			{
				tempf = Convert.ToDouble(PIntervalTextBox.Text);
			}
			catch
			{
				tempf = 0;
				NumberError();
                PIntervalTextBox.Text="0";
			}
			if(tempf >= 0)
				PWriteInterval = (System.Int32) tempf*1000;
			else
				PIntervalTextBox.Text="0";
		
		}

		private void CIntervalTextBox_TextChanged(object sender, System.EventArgs e)
		{
			System.Double tempf;
			try
			{
				tempf = Convert.ToDouble(CIntervalTextBox.Text);
			}
			catch
			{
				tempf = 0;
				NumberError();
				CIntervalTextBox.Text="0";
			}
			if(tempf >= 0)
				//*** test
				// Simulate a little timing error
				CReadInterval = (System.Int32) tempf*1100;
			else
				CIntervalTextBox.Text="0";
		
		}

		private void NumberError()
		{
			MessageBox.Show
				("Number must be between 0 and 31 (N-1)",
				"IndexOutOfRangeException",
				MessageBoxButtons.OK, MessageBoxIcon.Error);	
			TimerOnTick(this, null);
			TimerOnTick(this, null);		
		}

		private void PNumber_TextChanged(object sender, System.EventArgs e)
		{
			System.Int32 tempi;
			try
			{
				tempi = Convert.ToInt32(PNumberTextBox.Text);
			}
			catch
			{
				tempi = 1;
				NumberError();
				PNumberTextBox.Text="1";	
			}

			if( (tempi >= 0) && (tempi<=31))
				PWriteNumber = tempi*10;
			else
			{
				NumberError();
				PNumberTextBox.Text="1";	
			}
		}
		private void CNumberTextBox_TextChanged(object sender, System.EventArgs e)
		{
			System.Int32 tempi;
			try
			{
				tempi = Convert.ToInt32(CNumberTextBox.Text);
			}
			catch
			{
				tempi = 1;
				NumberError();
				CNumberTextBox.Text="1";	
			}

			if( (tempi >= 0) && (tempi<=31))
				CReadNumber = tempi*10;
			else
			{
				NumberError();
				CNumberTextBox.Text="1";	
			}
		
		}
		private void BWriteRadioButton_CheckedChanged(object sender, System.EventArgs e)
		{
			if(BWriteRadioButton.Checked)
			{
				PBlockingWrite = false;
				CBlockingRead = false;			
			}
			else
			{
				MessageBox.Show
					("Make sure you are in the Syncronous Mode",
					"ModeWarn",
					MessageBoxButtons.OK, MessageBoxIcon.Warning);	
				TimerOnTick(this, null);
				TimerOnTick(this, null);		
				PBlockingWrite = true;
				CBlockingRead = true;
			}
		}

		/*		private void BReadRadioButton_CheckedChanged(object sender, System.EventArgs e)
				{
					if(BReadRadioButton.Checked)
					{
						PBlockingWrite = false;
						CBlockingRead = false;			
					}
					else
					{
						PBlockingWrite = true;
						CBlockingRead = true;
					}
		
				}
		*/
		private void WMNumberTextBox_TextChanged(object sender, System.EventArgs e)
		{
			System.Int32 tempi;
			try
			{
				tempi = Convert.ToInt32(WMNumberTextBox.Text);
			}
			catch
			{
				tempi = 1;
				NumberError();
				CNumberTextBox.Text="1";	
			}

			if( (tempi >= 0) && (tempi<=31))
			{
				CReadWaterMark = tempi*10;
				theCB.Watermark = tempi*10;
			}
			else
			{
				NumberError();
				CNumberTextBox.Text="13";	
			}
		
		}

		private void ExitButton_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}


		//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//
		//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//

		// Delegate called by circular buffer for watermark event
		// This becomes the Consumer
		private void WaterMarkEvent(object sender, EventArgs e)
		{
			int[] Items = new int[360];
//			int i = 0;
 
			// copy them all
//			foreach(int element in theCB)
//				Items[i++] = element;

			// No, let the user decide how many to read at the watermark event
			theCB.CopyTo(Items,0,CReadNumber);

			// Check the data
			for( int i=0; i<CReadNumber; i+=10)
				for( int j=0; j<10; j++)
					if(Items[j] != j)
						MessageBox.Show
							("Data Error",
							"DataException",
							MessageBoxButtons.OK, MessageBoxIcon.Error);	

		}
		//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//
		//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//\\//


		/// <summary>
		/// Hard coded for a Circular Buffer of Size 36
		/// and a fixed window size
		/// </summary>
		/// 

		protected void PaintPage(Graphics grfx, Color clr, int cx, int cy)
		{
			bool PolygonOn = false;
			System.Int32 writeidx, readidx;
			Bitmap tempgr; 

			Graphics gr = this.panel1.CreateGraphics();

			tempgr = new Bitmap(CircleX, CircleY); 
			grfx = Graphics.FromImage(tempgr);

			float fScale = Math.Min(CircleX,CircleY)/1000f;
			grfx.TranslateTransform(CircleX/2, CircleY/2);
			grfx.ScaleTransform(fScale, fScale);

			grfx.Clear(Color.White);

			// draw the outer and inner circles of the buffer visual
			for(int iAngle = 0; iAngle < 360; iAngle += 6)
				grfx.DrawArc(pen, rectouter, iAngle, 6);
			for(int iAngle = 0; iAngle < 360; iAngle += 6)
				grfx.DrawArc(pen, rectinner, iAngle, 6);

			writeidx = CBwriteindex/10;
			readidx = CBreadindex/10;

			// as we advance around the circle, display the elements
			for(int i =0; i<360; i+=10)
			{ 
				if(i == writeidx)
				{
					PolygonOn = false; // display color for occupied slots
					pen.Color = Color.Red; // display write symbol
					grfx.DrawPie(pen, rectouter, 0, 10);
					grfx.DrawString("Buffer Head", 
						textFont, Brushes.Red,310,5);
					pen.Color = Color.Black; 
				}
				// must be before readindex check which shuts off Polygons
				if( (PolygonOn == true) && (CBcount >= 1) && (readidx != writeidx) )
				{
					grfx.FillPolygon(brush, apt);
				}
				if(i == readidx)
				{
					PolygonOn = true; // display color for occupied slots
					pen.Color = Color.Blue; // display write symbol
					grfx.DrawPie(pen, rectouter, 0, 10);
					grfx.DrawString("Buffer Tail", 
						textFont, Brushes.Blue,200,5);
					grfx.FillPolygon(brush, apt);
					pen.Color = Color.Black; 
				}
			
				grfx.RotateTransform(10);

			} // end for for 360 degrees
			// this handles saturation case
			if((writeidx - readidx) < 0)
			{
				for(int i =0; i<360; i+=10)
				{ 
					if(i == writeidx)
					{
						PolygonOn = false; // display color for occupied slots
					}
					// must be before readindex check which shuts off Polygons
					if( (PolygonOn == true) && (CBcount >= 1) )
					{
						grfx.FillPolygon(brush, apt);
					}
					if(i == readidx)
					{
						PolygonOn = true; // display color for occupied slots
						grfx.FillPolygon(brush, apt);
					}
			
					grfx.RotateTransform(10);

				} // end for for 360 degrees
			}

			pen.Color = Color.DarkOrange;

			grfx.DrawEllipse(pen,-25,-25,50,50);
			grfx.FillEllipse(Obrush,-25,-25,50,50);
			pen.Color = Color.Black;

			gr.DrawImage(tempgr, 0, 0);

		}
		
		/// <summary>
		/// Producer writes items into the Circular Buffer
		/// </summary>
		public class Producer
		{
			public Form1 Parent; // OO hoops

			// ten items = one element in the GUI
			int[] Items = {0,1,2,3,4,5,6,7,8,9}; 


			public Producer()
			{

			}

			public void Generate()
			{
				for(;;)
				{
					Thread.Sleep((System.Int32)PWriteInterval);
					if(Running==true)
					{
						try
						{
							int num;
							num = theCB.Count;
							// put in ten items, that is the smallest increment in the GUI
							if(PBlockingWrite==false)
							{
								for(int i=0; i<PWriteNumber/10; i++)
									theCB.Enqueue(Items);
							}
							else
							{
								for(int i=0; i<PWriteNumber/10; i++)
									theCB.EnqueueBlocking(Items);
							}
						}
						catch(IndexOutOfRangeException)
						{
							MessageBox.Show
								("No room in the Circular Buffer",
								"IndexOutOfRangeException",
								MessageBoxButtons.OK, MessageBoxIcon.Error);	
						}
						catch(ArgumentException)
						{
							MessageBox.Show
								("Must be in Syncronous Mode",
								"ArgumentException",
								MessageBoxButtons.OK, MessageBoxIcon.Error);	
						}
					}
				}

			}

		}// end Producer Class
		/// <summary>
		/// Consumer removes items from the Circular Buffer
		/// </summary>
		public class Consumer
		{
			public Form1 Parent; // OO hoops

			public Consumer()
			{

			}

			public void Consume()
			{
				int[] Items = new int[360]; 

				for(;;)
				{
					Thread.Sleep((System.Int32)CReadInterval);

					Array.Clear(Items, 0, Items.Length);

					// WaterMark consumes are in WaterMark event handler
					if( (Running==true) && (CBUseWaterMark==false) )
					{
						try
						{
							int num;
							num = theCB.Count;
							// copy out ten items, this method will
							// throw an exception if ten items are not avail.
							//REMEMBER, the second parm is the offset
							//							 theCB.CopyTo(Items,0);
							if(CBlockingRead==false)
								theCB.CopyTo(Items,0,CReadNumber);
							else
								theCB.CopyToBlocking(Items,0,CReadNumber);

							// Check the data
							for( int i=0; i<CReadNumber; i+=10)
								for( int j=0; j<10; j++)
									if(Items[j] != j)
										MessageBox.Show
										("Data Error",
										"DataException",
										MessageBoxButtons.OK, MessageBoxIcon.Error);	

						}
						catch(IndexOutOfRangeException)
						{
							MessageBox.Show
								("Too few items in the Circular Buffer",
								"IndexOutOfRangeException",
								MessageBoxButtons.OK, MessageBoxIcon.Error);	
						}
						catch(ArgumentException)
						{
							MessageBox.Show
								("Must be in Syncronous Mode",
								"ArgumentException",
								MessageBoxButtons.OK, MessageBoxIcon.Error);	
						}
					}
				}

			}

		}// end Consumer Class

	}// end Form1
} // end namespace
